#include <stdio.h>
#include <stdlib.h> /* For exit() function*/
int main()
{  char a[2000];//BFTree
   char b[2000];//J48
   char c[2000];//NaiveBayes
   char d[2000];//NaiveBayesMultinomial
   char e[2000];//LogisticRegression
   char r[2000];//Correct Classification
   char result[2000];
   int i=0,c1=0,c2=0,c3=0,c4=0,c5=0,c7=0;
   int max=0;
  
   int x,y;
   double counter=0.0,counter1=0.0,counter2=0.0,counter3=0.0,counter4=0.0,counter5=0.0;
   
   
      FILE *fptrb;
   if ((fptrb=fopen("C:/Users/fcalip/Desktop/machine learning/FC/ML/Classification_J48.txt","r"))==NULL){
       printf("Error! opening file.");
       exit(1);         /* Program exits if file pointer returns NULL. */
   }
   fscanf(fptrb,"%[^\n]",b);
   fclose(fptrb);
   
   
        FILE *fptrc;
   if ((fptrc=fopen("C:/Users/fcalip/Desktop/machine learning/FC/ML/Classification_NaiveBayes.txt","r"))==NULL){
       printf("Error! opening file");
       exit(1);         /* Program exits if file pointer returns NULL. */
   }
   fscanf(fptrc,"%[^\n]",c);
   fclose(fptrc);
   
   
        FILE *fptrd;
   if ((fptrd=fopen("C:/Users/fcalip/Desktop/machine learning/FC/ML/Classification_NaiveBayesMultinomial.txt","r"))==NULL){
       printf("Error! opening file");
       exit(1);         /* Program exits if file pointer returns NULL. */
   }
   fscanf(fptrd,"%[^\n]",d);
   fclose(fptrd);
   
           FILE *fptre;
   if ((fptre=fopen("C:/Users/fcalip/Desktop/machine learning/FC/ML/Classification_Logistic.txt","r"))==NULL){
       printf("Error! opening file");
       exit(1);         /* Program exits if file pointer returns NULL. */
   }
   fscanf(fptre,"%[^\n]",e);
   fclose(fptre);
   
   
        FILE *fptrr;
   if ((fptrr=fopen("C:/Users/fcalip/Desktop/machine learning/FC/ML/Classification_Correct.txt","r"))==NULL){
       printf("Error! opening file");
       exit(1);         /* Program exits if file pointer returns NULL. */
   }
   fscanf(fptrr,"%[^\n]",r);
   fclose(fptrr);
   
   
   
   for(i=0;i<2000;i++){
   	
   	if(a[i]=='1') c1++;
   	else if(a[i]=='2') c2++;
   	else if(a[i]=='3') c3++;
   	else if(a[i]=='4') c4++;
   	else if(a[i]=='5') c5++;
   	else if(a[i]=='7') c7++;
   	
    if(b[i]=='1') c1++;
   	else if(b[i]=='2') c2++;
   	else if(b[i]=='3') c3++;
   	else if(b[i]=='4') c4++;
   	else if(b[i]=='5') c5++;
   	else if(b[i]=='7') c7++;
   	
   	if(c[i]=='1') c1++;
   	else if(c[i]=='2') c2++;
   	else if(c[i]=='3') c3++;
   	else if(c[i]=='4') c4++;
   	else if(c[i]=='5') c5++;
   	else if(c[i]=='7') c7++;
   	
   	if(d[i]=='1') c1++;
   	else if(d[i]=='2') c2++;
   	else if(d[i]=='3') c3++;
   	else if(d[i]=='4') c4++;
   	else if(d[i]=='5') c5++;
   	else if(d[i]=='7') c7++;
   	
   	if(e[i]=='1') c1++;
   	else if(e[i]=='2') c2++;
   	else if(e[i]=='3') c3++;
   	else if(e[i]=='4') c4++;
   	else if(e[i]=='5') c5++;
   	else if(e[i]=='7') c7++;

   	char flag='7';
    max=c7;
    
    
   	if(c5>=max){
   		max=c5;
   		flag='5';
	   }
	   	if(c4>=max){
   		max=c4;
   		flag='4';
	   }
	   	if(c3>=max){
   		max=c3;
   		flag='3';
	   }
	   	if(c2>=max){
   		max=c2;
   		flag='2';
	   }
	   	if(c1>=max){
   		max=c1;
   		flag='1';
	   }  
	   
   	result[i]=flag;
   	max=0;
   	c1=0;
	c2=0;
	c3=0;
	c4=0;
	c5=0;
	c7=0;
   	
   }
   
   
   for(x=0;x<2000;x++)
   	printf("J48:%c  NaiveBayes:%c  BayesMulti:%c  Logistic:%c  | Result:%c | Correct:%c \n",b[x],c[x],d[x],e[x],result[x],r[x]);

   	
   	
	for(y=0;y<2000;y++){
		if(result[y]==r[y]) counter++;
		if(b[y]==r[y]) counter2++;
		if(c[y]==r[y]) counter3++;
		if(d[y]==r[y]) counter4++;
		if(e[y]==r[y]) counter5++;
	}
   printf("\n------------------------------------------------------------");	
   printf("\nMethod Accuracy= %.0f/2000    %f",counter,counter/2000);
   printf("\n------------------------------------------------------------");
   printf("\nJ48:%f      ",counter2/2000);
   printf("\nLogistic:%f" ,counter5/2000);
   printf("\nNaiveBayes:%f",counter3/2000);
   printf("\nBayesMulti:%f",counter4/2000);
      printf("\n-------------------------------------------------");
     printf("\n  Property of Fatih Calip");
	  printf("\n-------------------------------------------------");
   system("pause");
   
   return 0;
}

